<?php

/**
 * I belong to a file
 */

namespace App\Acme;

/**
 * I belong to a class
 */
class Foo
{
    /**
     * Gets the name of the application.
     */
    public function getName()
    {
        return 'Nginx PHP MySQL';
    }
}
